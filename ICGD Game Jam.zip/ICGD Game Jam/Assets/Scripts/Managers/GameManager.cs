﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : Observer
{
    // Start is called before the first frame update
    int lvlToLoad;
    public LevelManager lvlmanager;
    Player player;
    void Start()
    {
        player = FindObjectOfType(typeof(Player)) as Player;
        player.addObserver(this);
    }

    public void OnNotify(Event thing)
    {
        switch (thing)
        {
            case Event.PLAYER_WIN:
                lvlToLoad = lvlmanager.getCurrentLevel();
                lvlToLoad++;
                lvlmanager.loadLevel(lvlToLoad);
                break;
            case Event.PLAYER_DEATH:
                lvlToLoad = lvlmanager.getCurrentLevel();
                lvlmanager.loadLevel(lvlToLoad);
                 break;
        }
    }
}

public enum Event
{
    //every action triggered by the observer event system
    PLAYER_DEATH,
    PLAYER_WIN,
    PLAYER_JUMP,
    PLAYER_LAND,
    COLLECT_COIN
}