﻿using Scripts;
using UnityEngine;
using Utility;

namespace Managers
{
    [RequireComponent(typeof(AudioSource))]
    public class AudioManager : Observer
    {
        AudioSource _source;
        public AudioClip collectionSound;
        public AudioClip jumpSound;
        public AudioClip landSound;
        public AudioClip deathSound;

        private void Awake()
        {
            _source = GetComponent<AudioSource>();

            Player player = FindObjectOfType(typeof(Player)) as Player;
            player.AddObserver(this);

            LaundryManager lm = FindObjectOfType(typeof(LaundryManager)) as LaundryManager;
            lm.AddObserver(this);
            lm.AddObserver(this);
        }

        void PlayVFX(AudioClip clip)
        {
            _source.pitch = Random.Range(0.9f, 1.1f);
            _source.volume = Random.Range(0.4f,0.6f);
            _source.clip = clip;
            _source.Play();
        }


        public override void OnNotify(Event thing)
        {
            //responds to events
            switch (thing)
            {
                case Event.COLLECT_COIN:
                    Debug.Log("Coin Collect Sound.");
                    PlayVFX(collectionSound);
                    break;
                case Event.PLAYER_JUMP:
                    Debug.Log("Jump Sound.");
                    PlayVFX(jumpSound);
                    break;
                case Event.PLAYER_WIN1:
                    PlayVFX(landSound);
                    break;
                case Event.PLAYER_DEATH1:
                    PlayVFX(deathSound);
                    break;
                
            }
        }
    }
}