﻿using Scripts;
using UnityEngine;
using Utility;
using UI;

namespace Managers
{
    [RequireComponent(typeof(AudioSource))]
    public class UISoundManager : Observer
    {
        AudioSource _source;
        public AudioClip selectSound;



        private void Awake()
        {
            _source = GetComponent<AudioSource>();

             UIBehavior ui = FindObjectOfType(typeof(UIBehavior)) as UIBehavior;
            ui.AddObserver(this);

        }

        void PlayVFX(AudioClip clip)
        {
            //_source.pitch = 1f;
            //_source.volume = Random.Range(0.3f, 0.5f);
            _source.clip = clip;
            _source.Play();
        }


        public override void OnNotify(Event thing)
        {
            Debug.Log("notes received");
            //responds to events
            switch (thing)
            {
                case Event.PLAYER_SELECT:
                    Debug.Log("Coin Collect Sound.");
                    PlayVFX(selectSound);
                    break;
                
            }
        }
    }
}
