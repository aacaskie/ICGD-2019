﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
namespace Managers
{
    public class GameManager : MonoBehaviour
    {
       

        // Update is called once per frame
        void Update()
        {
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                // Let's just end the game here
#if UNITY_EDITOR
                UnityEditor.EditorApplication.isPlaying = false;
#else
                if (SceneManager.GetActiveScene().buildIndex != 0) {
                    SceneManager.LoadScene(0);
                }else{
                  Application.Quit();
                }
#endif
            }
        }
    }

    public enum Event
    {
        //every action triggered by the observer event system
        PLAYER_DEATH,
        PLAYER_JUMP,
        PLAYER_LAND,
        PLAYER_WIN,
        COLLECT_COIN,
        PLAYER_SELECT,
        PLAYER_DEATH1,
        PLAYER_WIN1
    }
}