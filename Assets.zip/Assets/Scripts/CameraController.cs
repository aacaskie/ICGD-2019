﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
  public Transform target;
    public float damping;

    Vector3 dest;

    float Zoffset;

    private void Start()
    {
        dest = new Vector3(target.position.x + 4f, 0, -10);
    }

    private void Update()
    {
            dest = new Vector3(target.position.x + 2f, target.position.y, -10);

        //if (Input.GetAxis("Horizontal") >0)
        //{
        //    dest = new Vector3(target.position.x + 4f, target.position.y, -10);
        //}
        //else if (Input.GetAxis("Horizontal") < 0)
        //{
        //    dest = new Vector3(target.position.x - 4f, target.position.y, -10);
        //}
        //else
        //{
        //    dest = new Vector3(target.position.x, target.position.y, -10);
        //}
        transform.position = Vector3.Lerp(transform.position, dest, damping * Time.deltaTime);
    }
}
