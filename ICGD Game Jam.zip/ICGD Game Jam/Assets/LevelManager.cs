﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelManager: MonoBehaviour
{   
   

    public int getCurrentLevel()
    {
        return SceneManager.GetActiveScene().buildIndex;
    }

    public void loadLevel(int lvl)
    {
        if (lvl <= SceneManager.sceneCountInBuildSettings)
        {
            StartCoroutine(Load(lvl));
        }
        else
        {
            Debug.Log("failed to load level does not exist.");
            StartCoroutine(Load(0));
        }
    }
    IEnumerator Load(int lvl)
    {
        AsyncOperation loadinglevel = SceneManager.LoadSceneAsync(lvl, LoadSceneMode.Single);
      Debug.Log("loading scene");
        yield return loadinglevel;
    }

}

