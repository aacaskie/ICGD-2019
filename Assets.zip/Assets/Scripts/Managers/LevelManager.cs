﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using Utility;
using Scripts;
namespace Managers
{
    public class LevelManager : Observer
    {

        Player player;
        // Start is called before the first frame update
        void Start()
        {
            if (SceneManager.GetActiveScene().buildIndex != 0)
            {
                player = FindObjectOfType<Player>();
                player.AddObserver(this);
            }
        }

        public override void OnNotify(Event thing)
        {
            switch (thing)
            {
                case Event.PLAYER_DEATH:
                    Debug.Log("reloading");
                    LoadLevel(GetCurrentLevel());
                    break;
                case Event.PLAYER_WIN:
                    PlayerPrefs.SetInt("LevelsWon", GetCurrentLevel());
                    LoadLevel(GetCurrentLevel() + 1);

                    break;
            }
        }

        public int GetCurrentLevel()
        {
            return SceneManager.GetActiveScene().buildIndex;
        }

        public void LoadLevel(int lvl)
        {
            if (lvl < SceneManager.sceneCountInBuildSettings)
            {
                //StartCoroutine(Load(lvl));
                SceneManager.LoadScene(lvl, LoadSceneMode.Single);
            }
            else
            {
                Debug.Log("failed to load level does not exist.");
                //StartCoroutine(Load(0));
                SceneManager.LoadScene(0, LoadSceneMode.Single);
            }
        }

        //IEnumerator Load(int lvl)
        //{
        //    SceneManager.LoadScene(lvl, LoadSceneMode.Single);
        //    //AsyncOperation loadinglevel = SceneManager.LoadSceneAsync(lvl, LoadSceneMode.Single);
        //    //while (!loadinglevel.isDone)
        //    //{
        //    //    yield return null;
        //    //}
        //}
    }
}