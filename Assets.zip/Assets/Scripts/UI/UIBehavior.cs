﻿using Managers;
using UnityEngine;
using UnityEngine.UI;
using Utility;

namespace UI
{
    public class UIBehavior : Subject
    {
        Animator anim;
        public Button startButton;
        public Button levelButton;
        public Button controlButton;
        public Image[] knobs;

        //level select
        public GameObject levelSelect;
        public Image level1;
        public Image level2;
        public Image level3;
        public Image level4;
        public Image level5;
        public Text levelSelector;
        int levelTextSelector;
        int levels;
        //Credits
        public Image Credits;

        bool isLevelSelect;
        bool isControls;

        LevelManager _lvlManager;
        int _currentSelection;
        private int _numberOfOptions = 3;

        private void Start()
        {
            _lvlManager = GetComponent<LevelManager>();
            anim = GetComponent<Animator>();

            _currentSelection = 0;

            foreach (var knob in knobs)
            {
                knob.enabled = false;
            }

            knobs[0].enabled = true;
            startButton.image.color = new Color(1, 1, 1, 0.75f);

            //levelSelect.active = false;
            isLevelSelect = false;
            isControls = false;

            anim.SetInteger("numLevelCompleted",PlayerPrefs.GetInt("LevelsWon"));
            levels = PlayerPrefs.GetInt("LevelsWon");
            Debug.Log(levels);
            Credits.enabled = false;
            levelSelector.enabled = false;

        }

        private void Update()
        {
            if (isLevelSelect)
            {
                handleLevelSelect();
            }
            else if (isControls)
            {
                handleCredits();
            }
            else
            {
                HandleInput();
            }
        }

        private void HandleInput()
        {
            if (Input.GetKeyDown(KeyCode.DownArrow) && _currentSelection != 2)
            {
                _currentSelection++;
                Selection(Mathf.Clamp(_currentSelection, 0, knobs.Length));
            }

            if (Input.GetKeyDown(KeyCode.UpArrow) && _currentSelection != 0)
            {
                _currentSelection--;
                Selection(_currentSelection);
            }

            if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.Space))
            {
                switch (_currentSelection)
                {
                    case 0:
                        _lvlManager.LoadLevel(1);
                        break;
                    case 1:
                        //level select
                        SetUpLevelSelect(true);
                        break;
                    case 2:
                        //controls
                        isControls = true;
                        Credits.enabled = true;

                        break;
                }
            }
        }

        private void Selection(int cs)
        {
            ResetKnobs();
            knobs[cs].enabled = true;
            Notify(Managers.Event.PLAYER_SELECT);

            switch (cs)
            {
                case 0:
                    startButton.image.color = new Color(1, 1, 1, 0.75f);
                    levelButton.image.color = new Color(1, 1, 1, 0.50f);
                    controlButton.image.color = new Color(1, 1, 1, 0.50f);
                    break;

                case 1:
                    startButton.image.color = new Color(1, 1, 1, 0.50f);
                    levelButton.image.color = new Color(1, 1, 1, 0.50f);
                    controlButton.image.color = new Color(1, 1, 1, 0.75f);
                    break;

                case 2:
                    startButton.image.color = new Color(1, 1, 1, 0.50f);
                    levelButton.image.color = new Color(1, 1, 1, 0.75f);
                    controlButton.image.color = new Color(1, 1, 1, 0.50f);
                    break;
            }
        }

        private void ResetKnobs()
        {
            foreach (var knob in knobs)
            {
                knob.enabled = false;
            }
        }

        private void SetUpLevelSelect(bool state)
        {
            //levelSelect.active = state;
            levelTextSelector = 1;
            anim.SetBool("isLevelSelect", state);
            levelSelector.enabled = state;
            Image[] temp = new Image[5];
            temp[0] = level1;
            temp[1] = level2;
            temp[2] = level3;
            temp[3] = level4;
            temp[4] = level5;

            for (int i = 0; i < temp.Length; i++)
            {
                if (i < levels + 1)
                {
                    temp[i].color = new Color(1, 1, 1);
                    Text scoreText = temp[i].GetComponentInChildren<Text>();
                    string finder = ("Level" + (i + 1));
                    scoreText.text = (PlayerPrefs.GetFloat(finder)+ " %");
                }
                else
                {
                    temp[i].color = new Color(0.5f, 0.5f, 0.5f);
                }
            }
            isLevelSelect = state;


        }
        void handleCredits()
        {
            if (Input.GetKeyDown(KeyCode.Space)|| Input.GetKeyDown(KeyCode.Return))
            {
                Credits.enabled = false;
                isControls = false;
            }
        }
        void handleLevelSelect()
        {
            if (Input.GetKeyDown(KeyCode.LeftArrow))
            {
                if (levelTextSelector > 1)
                {
                    levelTextSelector--;
                    Notify(Managers.Event.PLAYER_SELECT);
                    float xpos = levelSelector.transform.position.x;
                    float ypos = levelSelector.transform.position.y;

                    xpos -= 150f;
                    levelSelector.transform.position = new Vector3(xpos, ypos, 0f);
                    levelSelector.text = ("Level " + levelTextSelector);

                }
                else
                {
                    SetUpLevelSelect(false);

                }

            }
            if (Input.GetKeyDown(KeyCode.RightArrow) && levelTextSelector < levels + 1)
            {
                if (levelTextSelector <=5)
                {
                    levelTextSelector++;
                    Notify(Managers.Event.PLAYER_SELECT);
                    float xpos = levelSelector.transform.position.x;
                    float ypos = levelSelector.transform.position.y;

                    xpos += 150f;
                    levelSelector.transform.position = new Vector3(xpos, ypos, 0f);
                    levelSelector.text = ("Level " + levelTextSelector);
                }


            }
            if (Input.GetKeyDown(KeyCode.Return)|| Input.GetKeyDown(KeyCode.Space))
            {
                switch (levelTextSelector)
                {
                    case 1:
                        _lvlManager.LoadLevel(1);

                        break;
                    case 2:
                        _lvlManager.LoadLevel(2);

                        break;
                    case 3:
                        _lvlManager.LoadLevel(3);

                        break;
                    case 4:
                        _lvlManager.LoadLevel(4);

                        break;
                    case 5:
                        _lvlManager.LoadLevel(5);
                        break;
                }
            }


        }
    }
}