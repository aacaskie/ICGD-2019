﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;
using Utility;
using Event = Managers.Event;

namespace Scripts
{
    public class Player : Subject
    {
        //components
        BoxCollider2D col;
        Rigidbody2D rb;
        SpriteRenderer sp;

        private PlayerState _state;

        //physics
        public float speed = 5f;
        public float jumpHeight = 1000f;
        float maxAcceleration = 10f;

        bool isGrounded;
        bool isPaused;

        public LayerMask platformLayer;
        public Transform groundCheck;

        public Sprite playerIdle;
        public Sprite playerRun;
        public Sprite playerDie;
        public Sprite playerWin;
        public Sprite playerJump;
        public Sprite playerLand;

        private void Start()
        {
            _state = PlayerState.Idle;
            rb = GetComponent<Rigidbody2D>();
            col = GetComponent<BoxCollider2D>();
            sp = GetComponent<SpriteRenderer>();
            //bubbles = GetComponentInChildren<ParticleSystem>();

            //col.enabled = true;
            isGrounded = true;
            isPaused = false;
            GetComponentInChildren<TrailRenderer>().enabled = true;



        }

        private void FixedUpdate()
        {
            if (!isPaused)
            {
                HandlePlayerState();
            }
        }

        private void OnTriggerEnter2D(Collider2D collision)
        {
            if (collision.gameObject.tag == "Goal")
            {
                    _state = PlayerState.PlayerWin;

            }
        }
        private void Update()
        {
            var hit = Physics2D.Raycast(transform.position, Vector2.down, 1f, platformLayer);
            if (hit.transform && hit.transform.CompareTag("Spikes"))
            {
                //watch out for spikes
                _state = PlayerState.Death;
            }
            //else if (hit.transform && hit.transform.CompareTag("Goal"))
            //{
            //    _state = PlayerState.PlayerWin;
            //}
        }

        private void HandlePlayerState()
        {
            switch (_state)
            {
                case PlayerState.Idle:

                    if (rb.velocity == Vector2.zero)
                    {
                        sp.sprite = playerIdle;
                    }

                    if ((Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.RightArrow)) && Input.GetKey(KeyCode.UpArrow )&& rb.velocity.y == 0f)
                    {
                        if (isGrounded)
                        {
                            Accelerate();
                            rb.AddForce(new Vector2(0, jumpHeight));
                            isGrounded = false;
                            Notify(Event.PLAYER_JUMP);
                            _state = PlayerState.Jumping;
                        }
                    }
                    if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.RightArrow))
                    {
                        //handle Idle State Change
                     
                            _state = PlayerState.Walking;
                        

                    }
                    else if (Input.GetKey(KeyCode.UpArrow) && rb.velocity.y == 0f)
                    {
                        rb.AddForce(new Vector2(0, jumpHeight));
                        isGrounded = false;
                        Notify(Event.PLAYER_JUMP);
                        _state = PlayerState.Jumping;
                    }

                    break;

                case PlayerState.Walking:
                    if (rb.velocity.y == 0)
                    {
                        sp.sprite = playerRun;
                    }
                    if (rb.velocity.x >0)
                    {
                        transform.localScale = new Vector3(1,1,1);
                    }
                    else
                    {
                        transform.localScale = new Vector3(-1, 1, 1);

                    }
                    if (Input.GetKeyUp(KeyCode.LeftArrow) || Input.GetKeyUp(KeyCode.RightArrow) || rb.velocity.x == 0f)
                    {
                        _state = PlayerState.Idle;
                    }
                    else if (Input.GetKey(KeyCode.UpArrow) && rb.velocity.y == 0f)
                    {
                        rb.AddForce(new Vector2(0, jumpHeight));
                        isGrounded = false;
                        Notify(Event.PLAYER_JUMP);
                        _state = PlayerState.Jumping;

                    }else if ((Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.RightArrow))&& Input.GetKey(KeyCode.UpArrow) && rb.velocity.y == 0f)
                    {
                        if (isGrounded)
                        {
                            Accelerate();
                            rb.AddForce(new Vector2(0, jumpHeight));
                            isGrounded = false;
                            Notify(Event.PLAYER_JUMP);
                            _state = PlayerState.Jumping;
                        }
                    }

                    Accelerate();
                    break;

                case PlayerState.Jumping:
                    sp.sprite = playerJump;
                    //anim.SetBool("isRunning", false);
                    //anim.SetBool("isJumping", true);
                    //handle Jumping code

                    Debug.DrawRay(transform.position, Vector2.down * 1f, Color.green, 2.0f);
                    var targetSize = new Vector2(0.1f, 0.1f);
                    var hit = Physics2D.CircleCast(groundCheck.position, 0.3f, Vector2.down, 0f, platformLayer);
                    //RaycastHit2D hit = Physics2D.Raycast(transform.position,Vector2.down,0.5f,platformLayer);

                    if (hit.transform)
                    {
                        if (hit.collider.transform.CompareTag(("Platforms")))
                        {
                            isGrounded = true;
                        }
                    }

                    //handle Jumping State Change
                    if (isGrounded)
                    {
                        _state = PlayerState.Landing;
                    }

                    break;

                case PlayerState.Landing:
                     
                    _state = PlayerState.Idle;
                    break;

////handle Ducking code
                    //break;

                case PlayerState.Death:
                    sp.sprite = playerDie;
                    //anim.SetTrigger("isLose");
                    StartCoroutine(HandlePlayerDeath());
                    break;

                case PlayerState.PlayerWin:
                    sp.sprite = playerWin;
                    //anim.SetTrigger("isWin");
                    Debug.Log("*** Player Win ***");
                    StartCoroutine(HandlePlayerWin());
                    break;
                
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }


        void Accelerate()
        {


            if (rb.velocity.magnitude < maxAcceleration)
            {
                float x = rb.velocity.x;
                x += speed * Input.GetAxis("Horizontal");
                rb.velocity = new Vector2(x, rb.velocity.y);
                //rb.AddForce(Vector2.right * Speed * Input.GetAxis("Horizontal"));
            }
            else
            {
                rb.velocity = new Vector2(maxAcceleration * Input.GetAxis("Horizontal"), rb.velocity.y);
            }
        }

        IEnumerator HandlePlayerDeath()
        {
            Notify(Event.PLAYER_DEATH1);
            GetComponentInChildren<TrailRenderer>().enabled = false;
            rb.velocity = Vector2.zero;
            transform.RotateAroundLocal(Vector3.up, 0.5f);
            yield return new WaitForSeconds(0.5f);
            Notify(Event.PLAYER_DEATH);
        }

        IEnumerator HandlePlayerWin()
        {
            Notify(Event.PLAYER_WIN1);

            //col.enabled = false;
            rb.velocity = Vector2.zero;

            isPaused = true;
            
            yield return new WaitForSeconds(1f);
            Notify(Event.PLAYER_WIN);
        }
       
    }

    enum PlayerState
    {
        Idle,
        Walking,
        Jumping,
        Landing,
        Ducking,
        Death,
        PlayerWin
    }
}