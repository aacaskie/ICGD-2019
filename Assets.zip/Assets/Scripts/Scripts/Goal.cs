﻿using UnityEngine;

namespace Scripts
{
    public class Goal : MonoBehaviour
    {
        // Start is called before the first frame update
        void Start()
        {
        }

        // Update is called once per frame
        void Update()
        {
        }
    }
}