﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class continuousSound : MonoBehaviour
{
    public static continuousSound instance;
    private void Awake()
    {
        if (instance != null)
        {
            Destroy(this.gameObject);
        }
        else
        {
            instance = this;
            if (SceneManager.GetActiveScene().buildIndex != 0)
            {
                DontDestroyOnLoad(this.gameObject);
            }
            else
            {
                Destroy(this.gameObject);
            }
        }
    }
    private void Update()
    {

            if (SceneManager.GetActiveScene().buildIndex == 0)
            {
                Destroy(this.gameObject);
            }
    }

}
