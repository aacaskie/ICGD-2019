﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Managers;
using Utility;
using Scripts;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class GameplayUI : Observer
{
    LaundryManager laundry;

    Player player;
    public Text scoreboard;
    int currentscore;
    int totalScore;
    private void Start()
    {
        player = FindObjectOfType<Player>();
        player.AddObserver(this);
        laundry = FindObjectOfType<LaundryManager>();
        laundry.AddObserver(this);
        UpdateGameplayUI(0, laundry.initialLaundry);
        scoreboard.enabled = false;
        currentscore = 0;

    }


    public void UpdateGameplayUI(int num1, int num2)
    {
        Debug.Log("updated score");
        scoreboard.text = (num1 + " / " + num2);
    }

    public override void OnNotify(Managers.Event thing)
    {
        //responds to events
        switch (thing)
        {
            case Managers.Event.COLLECT_COIN:
                scoreboard.enabled = true;
                totalScore = laundry.initialLaundry;
                currentscore++;
                UpdateGameplayUI(currentscore, laundry.initialLaundry);
                //float FinalScore = ((float)currentscore / (float)totalScore) * 100f;
                //Debug.Log(currentscore + "/ "+ totalScore+ "* 100="+ FinalScore);
                break;
            case Managers.Event.PLAYER_DEATH:
                currentscore = 0;
                UpdateGameplayUI(currentscore , laundry.initialLaundry);

                break;
            case Managers.Event.PLAYER_WIN:
                string name = ("Level" + SceneManager.GetActiveScene().buildIndex);
                float FinalScore = ((float)currentscore / (float)totalScore) * 100f;
                FinalScore = Mathf.Round(FinalScore);
                //Debug.Log(FinalScore);
                PlayerPrefs.SetFloat(name, FinalScore);
             
                Debug.Log(PlayerPrefs.GetFloat(name));
                break;
        }
         }
        }
